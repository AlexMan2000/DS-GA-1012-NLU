# EC 1: Written Problems

### Problem 2a

* `a` represents a scalar.
* `b` represents a vector.
* `c` represents a matrix.
* `d` represents a tensor (i.e., a 3D grid of numbers).

### Problem 2b

The `.shape` of an array is a `tuple` of `int`s describing the dimensions of the array. For example, the `.shape` of
a vector is the number of entries in the vector; the `.shape` of a matrix is the number of rows and columns of the
matrix; and the `.shape` of a scalar (0D array) is the empty tuple `()`.

### Problem 2c 

* Line 1 returns the first ("0th") row of `c`.
* Line 2 returns the first ("0th") column of `c`.
* Line 3 returns the last row of `c`.
* Line 4 returns all rows of `c` except for row 0.
* Line 5 turns `c` into a 3D array of shape `(2, 1, 3)` (i.e., it inserts a new axis into position `1`).

### Problem 2d

* `+` implements addition.
* `-` implements subtraction.
* `*` implements Hadamard multiplication.
* `/` implements Hadamard division.

### Problem 2e

* `.T` transposes a matrix.
* `@` implements dot product (between vectors) or matrix multiplication (between matrices).

### Problem 2f 

If `x` and `y` are arrays of dimension 3 or higher, then `x @ y` is defined as long as `y.shape[-1] == x.shape[-2]`.
The two arrays are treated as collections of matrices organized into a grid. `x @ y` also contains a grid of
matrices, where each item in the grid contains the matrix product of the corresponding matrices from `x` and `y`.

For example, suppose `x.shape == (k, m, n)` and `y.shape == (k, n, p)`. `x` can be viewed as a list of `k` matrices,
each with `m` rows and `n` columns. `y` can be viewed as a list of `k` matrices, each with `n` rows and `p` columns.
The product `x @ y` has shape `(k, m, p)`. It is a list of `k` matrices, each with `m` rows and `p` columns. Each
matrix in `x @ y` is the product of the corresponding matrices from `x` and `y`. In other words, for each `i`,
`(x @ y)[i] == x[i] @ y[i]`.

### Problem 2g 

* `.sum()` returns the sum of all entries in an array.
* The `axis` keyword argument causes the sum to be taken "along" a particular axis of the array. For example, if `c`
  is a 2D array (a matrix), then `c.sum(axis=0)` returns the sum of each column of the array, and `c.sum(axis=1)`
  returns the sum of each row of the array. In general, if `axis=k` is passed to `.sum()`, then the entries of the
  array with the same indices in all axes other than `k` are added together.
* If both `axis=k` and `keepdims=False` (the default value) are passed to `.sum()`, then the `k`th axis is deleted
  from the sum. If `axis=k` and `keepdims=True` are passed to `.sum()`, then the `k`th axis is not deleted, but
  replaced with an axis of size 1. If `axis=k` is not passed to `.sum()`, then `keepdims=False` causes `.sum()` to
  return a 0D array; otherwise `.sum()` will have the same number of dimensions as the original array.

### Problem 2h

`.reshape` changes the `.shape` of an array to a specified shape. 

### Problem 2i

In lines 2–4, changing the third row (row `2`) of `f` also changes the corresponding values `d`. In lines 7–10, 
however, changing the values of `g` has no effect on `d`.

Since `f` is obtained by calling `.reshape` on `d`, this shows that the output of `.reshape` contains _references_ 
to the memory locations of the original array. When `.copy()` is called, the values in those memory locations are 
copied to a new memory location, which is why changing the values of `g` has no effect on `d` or `f`.