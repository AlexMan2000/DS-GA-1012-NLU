# EC 1 Solutions

These are solutions to [EC 1](https://github.com/NYU-DSGA1012-S24/ec1). The written solutions are available in Markdown format instead of PDF.
