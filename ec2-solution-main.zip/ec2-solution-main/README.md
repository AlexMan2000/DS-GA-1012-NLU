# EC 2 Solutions

These are solutions to [EC 2](https://github.com/NYU-DSGA1012-S24/ec2). The written solutions are available in Markdown format instead of PDF.
