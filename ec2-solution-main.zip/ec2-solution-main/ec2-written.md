# EC 2: Written Problems

### Problem 2a

A tensor represents a node in a computation graph. Each tensor has a _value_. Tensors that contain a scalar value have a `.backward()` method, which causes gradients to be computed via automatic differentiation (a.k.a. the backpropagation algorithm). Leaf nodes in a computation graph have a `.grad` property and a `.requires_grad` flag (i.e., `.requires_grad` is an instance variable with a boolean value). When `.requires_flag` is set to `True`, gradients computed by calling `.backward()` on a node higher in the graph are stored in the `.grad` property. The stored gradients _accumulate_ in the sense that each time `.backward()` is called, the gradients are _added_ to the existing value of `.grad` when available.

### Problem 2b

`b`, `c`, `d`, and `e` are all tensors that contain the same data as `a`. However, in `b` and `e` the data are stored as 32-bit floats, while in `c` and `d` the data are stored as 64-bit ints. `f` is a tensor of shape `(2, 3)` initialized to random values that are close to 0.

### Problem 2c

`torch.full(s, v)` creates a tensor of shape `s`, completely filled in with the value `v`. `torch.randn(*s)` creates a tensor of shape `s` with random values generated from a normal distribution with mean 0 and variance 1.

### Problem 2d

`c.requires_grad` cannot be set to `True` because the values of `c` are 64-bit ints, and functions cannot be differentiable by definition if they only take integer-valued inputs.

### Problem 2e

```python
print(a.sum(dim=-1))
print(a.unsqueeze(-1).shape)  # alternatively, print(a[:, None].shape)
print(a.view(4, -1))
print(a.numel())
```

### Problem 2f

`torch.ones(*s)` creates a tensor of shape `s` filled with the value 1. It does the same thing as `torch.full(s, 1)`.

`torch.cat` concatenates a list of tensors "along" the specified dimension. That is to say, if `l_` is a list of `n`-dimensional tensors and `d` is a dimension, then the code `torch.cat(l_, dim=d)` runs only if the tensors in `l_` all have the same shape, except in dimension `d`. Thinking of each item of `l_` as a list of `(n - 1)`-dimensional tensors indexed by its position along dimension `d`, the result of `torch.cat(l_, dim=d)` is the concatenation of these lists of tensors.

### Problem 3a

`model` is a two-layer perceptron with tanh activation.

### Problem 3b

`x` is a tensor of shape `(5, 7)` with integer values ranging from 0 to 99 (inclusive). The values represent indices in a vocabulary with 100 distinct token types, and the tensor `x` represents a mini-batch containing 5 sequences of tokens with a maximum length of 7.

`embeddings` is a tensor of shape `(5, 7, 20)`, where each of the indices in `x` has been replaced by its corresponding 20-dimensional word embedding, contained in `embedding_layer`. For example, if `x[i, j] == 43`, then `embeddings[i, j]` is a tensor of shape `(20,)` containing the word embedding for the 44th item in the vocabulary.

`h` is a tensor of shape `(5, 7, 9)`, containing the output of the LSTM. The LSTM maps a sequence of "embedding vectors" to a sequence of "hidden vectors." Typically, the hidden vector in the position of the `[EOS]` token is treated as an "embedding" for the entire sequence. For example, in an LSTM classifier, if `x[i, j]` contains the `[EOS]` token for item `i` in the mini-batch, then logits for a predicted label are obtained by feeding `h[i, j]` into an unembedding layer.

### Problem 3c

`loss.backward()`
